package com.example.javafxapp;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.FileChooser;

import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.net.Socket;
import java.net.URI;
import java.net.URL;
import java.security.*;
import java.util.ResourceBundle;

public class CryptoController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private ChoiceBox<String> chipherComboBox;

    @FXML
    private Button fileButton;

    @FXML
    private TextField filePathLabel;

    @FXML
    private Button sendButton;

    @FXML
    private TextField serverLocationLabel;

    @FXML
    private ChoiceBox<String> signatureCombobox;

    @FXML
    private TextField keyLabel;

    final FileChooser fileChooser = new FileChooser();

    private PublicKey publicKey = null;

    private static File signFile = null;

    private String doEnc(File inputFile, String algorithm) throws IOException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        //Создание нового временного файла с результатами шифрования в папке с оригинальным
        String outputFilePath = inputFile.getParent() + "\\enc_" + inputFile.getName();
        File outputFile = new File(outputFilePath);
        try (FileInputStream inputStream = new FileInputStream(inputFile); FileOutputStream outputStream = new FileOutputStream(outputFile)) {
            // Создание ключа
            KeyGenerator keyGen = KeyGenerator.getInstance(algorithm);
            if (algorithm.equals("AES")) {
                keyGen.init(128); // для AES ключ должнен быть 128, 192 или 256 бит)
            }
            SecretKey randomKey = keyGen.generateKey();
            byte[] keyBytes = randomKey.getEncoded();
            Key secretKey = new SecretKeySpec(keyBytes, algorithm);
            //Создание экземпляра класса Cipher для шифрования в конструктор передаем "AES" или "DES"
            Cipher cipher = Cipher.getInstance(algorithm);
            //Выбор режима работы ENCRYPT_MODE (шифрование)
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);
            //Получение данных для шифрования
            byte[] inputBytes = new byte[(int) inputFile.length()];
            inputStream.read(inputBytes);
            //Сама операция шифрования (doFinal) и запись полученных байтов в файл для отправки
            byte[] outputBytes = cipher.doFinal(inputBytes);
            outputFile.createNewFile();
            outputStream.write(outputBytes);
            //Форматирование ключа в строку для передачи серверному приложению
            StringBuilder hexKey = new StringBuilder();
            for (byte b : keyBytes) {
                hexKey.append(String.format("%02X", b));
            }
            keyLabel.setText(String.valueOf(hexKey));
            return outputFilePath;
        }
    }

    private File doSign(File inputFile, String algorithm) {
        try (FileInputStream inputStream = new FileInputStream(inputFile); FileOutputStream outputStream = new FileOutputStream(inputFile.getParent() + "\\sign_" + inputFile.getName())) {
            //Генерация ключей
            KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance(algorithm);
            SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
            keyPairGen.initialize(1024, random);
            KeyPair keyPair = keyPairGen.genKeyPair();
            PrivateKey privateKey = keyPair.getPrivate();
            publicKey = keyPair.getPublic();
            // Создание подписи
            Signature signature = Signature.getInstance("SHA1with" + algorithm);
            // Инициализация подписи закрытым ключом
            signature.initSign(privateKey);
            //Чтение файла и запись в массив байтов
            byte[] inputBytes = new byte[(int) inputFile.length()];
            inputStream.read(inputBytes);
            // Формирование цифровой подпись файла с закрытым ключом
            signature.update(inputBytes);
            // Байтовый массив цифровой подписи
            byte[] realSignature = signature.sign();
            // Сохранение цифровой подписи сообщения в файл
            outputStream.write(realSignature);
            return new File(inputFile.getParent() + "\\sign_" + inputFile.getName());
        } catch (NoSuchAlgorithmException | IOException | InvalidKeyException |
                 SignatureException e) {
            throw new RuntimeException(e);
        }
    }

    private static DataOutputStream dataOutputStream = null;
    private static DataInputStream dataInputStream = null;
    private static void sendFile(String path) throws Exception{
        //Отправка файла из заданного path
        int bytes = 0;
        File file = new File(path);
        FileInputStream fileInputStream = new FileInputStream(file);
        dataOutputStream.writeLong(file.length());
        byte[] buffer = new byte[4*1024];
        while ((bytes=fileInputStream.read(buffer))!=-1){
            dataOutputStream.write(buffer,0,bytes);
            dataOutputStream.flush();
        }
        fileInputStream.close();
    }


    @FXML
    void initialize() {
        publicKey = null;
        //Действие на кнопку "Выбрать файл..."
        fileButton.setOnAction(actionEvent -> {
            //Вызов окна выбора файла
            File file = fileChooser.showOpenDialog(null);
            //Запись путь выбранного файла в поле "Путь"
            if (file != null) {
                filePathLabel.setText(file.getPath());
            }
        });

        //Настройка содержимого выпадающих списков и выбор первого варианта по умолчанию
        chipherComboBox.getItems().addAll("Не использовать", "AES (Advanced Encryption Standard)", "DES (Data Encryption Standard)");
        chipherComboBox.getSelectionModel().selectFirst();
        signatureCombobox.getItems().addAll("Не использовать", "RSA (Rivest–Shamir–Adleman)", "DSA (Digital Signature Algorithm)");
        signatureCombobox.getSelectionModel().selectFirst();

        //Действие на кнопку "Отправить"
        sendButton.setOnAction(actionEvent -> {
            keyLabel.setText("");
            File inputFile = new File(filePathLabel.getText());

            File encryptedFile = null;
            signFile = null;

            //Выбор алгоритма шифрование согласно значению выпадающего списка
            switch (chipherComboBox.getSelectionModel().getSelectedIndex()) {
                case 0:
                    //Выбрана опция "Не использовать"
                    break;
                case 1:
                    //AES
                    try {
                        encryptedFile = new File(doEnc(inputFile, "AES"));
                    } catch (IOException | NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException |
                             IllegalBlockSizeException | BadPaddingException e) {
                        throw new RuntimeException(e);
                    }
                    break;
                case 2:
                    //DES
                    try {
                        encryptedFile = new File(doEnc(inputFile, "DES"));
                    } catch (IOException | NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException |
                             IllegalBlockSizeException | BadPaddingException e) {
                        throw new RuntimeException(e);
                    }
                    break;
                default: break;
            }

            //Выбор алгоритма цифровой подписи согласно значению выпадающего списка
            switch (signatureCombobox.getSelectionModel().getSelectedIndex()) {
                case 0:
                    //Выбрана опция "Не использовать"
                    break;
                case 1:
                    //RSA
                    if (encryptedFile != null) {
                        signFile = doSign(encryptedFile, "RSA");
                    } else {
                        signFile =doSign(inputFile, "RSA");
                    }
                    break;
                case 2:
                    //DSA
                    if (encryptedFile != null) {
                        signFile =doSign(encryptedFile, "DSA");
                    } else {
                        signFile =doSign(inputFile, "DSA");
                    }
                    break;
                default: break;
            }

            //Тернарный оператор определяющий какой файл отправлять
            File sendedFile = (encryptedFile != null) ? encryptedFile : inputFile;

            URI url = URI.create(serverLocationLabel.getText());

            //Подключение к серверу
            try(Socket socket = new Socket(url.getHost(),url.getPort())) {
                dataInputStream = new DataInputStream(socket.getInputStream());
                dataOutputStream = new DataOutputStream(socket.getOutputStream());

                //Отправка данных о выбранных алгоритмах шифрования и подписи
                dataOutputStream.writeInt(chipherComboBox.getSelectionModel().getSelectedIndex());
                dataOutputStream.writeInt(signatureCombobox.getSelectionModel().getSelectedIndex());

                //Отправка имени и расширения файла
                dataOutputStream.writeUTF(sendedFile.getName());

                //Отправка файла
                sendFile(sendedFile.getPath());

                //Отправка цифровой подписи и публичного ключа
                if (publicKey != null) {
                    dataOutputStream.writeUTF(signFile.getName());
                    sendFile(signFile.getPath());
                    byte[] publicKeyBytes = publicKey.getEncoded();
                    dataOutputStream.write(publicKeyBytes);
                }

                //Закрытие потоков ввода вывода и удаление временных файлов
                dataInputStream.close();
                dataOutputStream.close();

                signFile.deleteOnExit();
                encryptedFile.deleteOnExit();

                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Ура");
                alert.setHeaderText("Файл отправлен.");
                if (chipherComboBox.getSelectionModel().getSelectedIndex() != 0) {
                    alert.setContentText("Введите сгенерированный ключ серверу для расшифровки.");
                } else {
                    alert.setContentText("Операция выполнена успешно.");
                }
                alert.showAndWait().ifPresent(rs -> {});

            } catch (Exception e) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Ошибка");
                alert.setHeaderText("Что то не так, проверьте правильность введенных данных, доступность файла и сервера!");
                alert.setContentText("Текст ошибки: " + e.getMessage());
                alert.showAndWait().ifPresent(rs -> {});
            }
        });
    }
}
