import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Scanner;

public class Main {
    private static DataOutputStream dataOutputStream = null;
    private static DataInputStream dataInputStream = null;
    private static void receiveFile(String path) {
        //Получение файла и сохранение по заданному пути
        int bytes = 0;
        FileOutputStream fileOutputStream = null;
        try {
            fileOutputStream = new FileOutputStream(path);
            long size = dataInputStream.readLong();
            byte[] buffer = new byte[4*1024];
            while (size > 0 && (bytes = dataInputStream.read(buffer, 0, (int)Math.min(buffer.length, size))) != -1) {
                fileOutputStream.write(buffer,0,bytes);
                size -= bytes;
            }
            fileOutputStream.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private static boolean verifySignature(File inputFile, File signatureFile, PublicKey publicKey, String algorithm) {
        try (FileInputStream inputStream = new FileInputStream(inputFile);
             FileInputStream signatureInputStream = new FileInputStream(signatureFile)) {
            // Чтение файла и запись в массив байтов
            byte[] inputBytes = new byte[(int) inputFile.length()];
            inputStream.read(inputBytes);
            // Чтение цифровой подписи из файла
            byte[] signatureBytes = new byte[(int) signatureFile.length()];
            signatureInputStream.read(signatureBytes);
            // Инициализация подписи открытым ключом
            Signature signature = Signature.getInstance("SHA1with" + algorithm);
            signature.initVerify(publicKey);
            // Обновление подписи с данными файла
            signature.update(inputBytes);
            // Проверка цифровой подписи
            return signature.verify(signatureBytes);
        } catch (NoSuchAlgorithmException | IOException | InvalidKeyException | SignatureException e) {
            throw new RuntimeException(e);
        }
    }

    //Тоже что и шифрование в клиентском приложении только в режиме DECRYPT_MODE
    private static File doDec(File encFile, String hexKey, String algorithm) {
        File decryptedFile = new File(encFile.getParent() + "\\dec_" + encFile.getName());
        try (FileInputStream encStream = new FileInputStream(encFile); FileOutputStream decStream = new FileOutputStream(decryptedFile)) {
            int len = hexKey.length();
            byte[] keyBytes = new byte[len / 2];
            for (int i = 0; i < len; i += 2) {
                keyBytes[i / 2] = (byte) ((Character.digit(hexKey.charAt(i), 16) << 4) + Character.digit(hexKey.charAt(i+1), 16));
            }
            Key secretKey = new SecretKeySpec(keyBytes, algorithm);
            Cipher cipher = Cipher.getInstance(algorithm);
            cipher.init(Cipher.DECRYPT_MODE, secretKey);
            byte[] inputBytes = new byte[(int) encFile.length()];
            encStream.read(inputBytes);
            byte[] decryptedBytes = cipher.doFinal(inputBytes);
            decStream.write(decryptedBytes);
            return decryptedFile;
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | IOException |
                 IllegalBlockSizeException | BadPaddingException e) {
            throw new RuntimeException(e);
        }
    }


    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        try {
            System.out.print("В какую папку сохранять полученные файлы: ");
            String saveDirectory = in.nextLine();
            System.out.print("Какой порт прослушивать: ");
            int port = in.nextInt();
            in.nextLine();
            ServerSocket serverSocket = new ServerSocket(port);
            System.out.println("Сервер прослушивает порт " + port);
            boolean listen = true;
            while (listen) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("////////////////////////////////////////////////////////////////");

                dataInputStream = new DataInputStream(clientSocket.getInputStream());
                dataOutputStream = new DataOutputStream(clientSocket.getOutputStream());

                //Получение данных о выбранных алгоритмах шифрования и подписи
                int encAlg = dataInputStream.readInt();
                int signAlg = dataInputStream.readInt();

                //Получение имени и расширения файла
                String filename = dataInputStream.readUTF();

                //Получение файла
                String mainFilePath = saveDirectory + File.separator + filename;
                File mainFile = new File(mainFilePath);
                receiveFile(mainFilePath);
                System.out.println("Получен файл, сохраняю как " + mainFilePath);

                //Получение цифровой подписи и публичного ключа
                PublicKey publicKey = null;
                String signFilepath = null;
                File signFile = null;
                if (signAlg == 1 || signAlg == 2) {
                    signFilepath = saveDirectory + File.separator + dataInputStream.readUTF();
                    receiveFile(signFilepath);
                    signFile = new File(signFilepath);
                    boolean verify = false;
                    //Проверка подписи по публичному ключу
                    if (signAlg == 1) {
                        publicKey = KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(dataInputStream.readAllBytes()));
                        verify = verifySignature(mainFile, signFile, publicKey, "RSA");
                    } else {
                        publicKey = KeyFactory.getInstance("DSA").generatePublic(new X509EncodedKeySpec(dataInputStream.readAllBytes()));
                        verify = verifySignature(mainFile, signFile, publicKey, "DSA");
                    }
                    System.out.println("Получены цифровая подпись и публичный ключ.");
                    if (verify) {
                        System.out.println("Цифрования подпись верна");
                    } else {
                        System.out.println("Цифрования подпись не верна");
                    }
                }

                //Расшифровка файла
                if (encAlg == 1 || encAlg == 2) {
                    System.out.print("Похоже файл зашифрован, введите ключ сгенерированный клиентским приложением для расшифровки: ");
                    String hexKey = in.nextLine();
                    File decFile = null;
                    if (encAlg == 1) {
                        decFile = doDec(mainFile, hexKey, "AES");
                    } else {
                        decFile =doDec(mainFile, hexKey, "DES");
                    }
                    System.out.println("Файл расшифрован, сохранено как " + decFile.getPath());
                }

                dataInputStream.close();
                dataOutputStream.close();
                clientSocket.close();
            }
            System.out.println("Сервер выключен.");
            serverSocket.close();
        } catch (IOException | NoSuchAlgorithmException | InvalidKeySpecException e) {
            throw new RuntimeException(e);
        }
    }
}